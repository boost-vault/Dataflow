// Copyright 2007 Stjepan Rajko.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/functional/forward_adapter.hpp>
#undef BOOST_PP_INDIRECT_SELF
#include <boost/fusion/include/fused.hpp>
#include <boost/fusion/include/unfused_lvalue_args.hpp>
#include <boost/fusion/include/vector.hpp>
#include <boost/functional/factory.hpp>
#include <boost/switch.hpp>

#include <iostream>
#include <memory>

// base
template<typename F>
class delayed_call
{
public:
    virtual void make_call(F &f)=0;
    virtual ~delayed_call() {}
};

// holds a sequence of arguments, makes a call using them later
template<typename F, typename Sequence>
class delayed_call_template : public delayed_call<F>
{
public:
    delayed_call_template(const Sequence &sequence) : m_sequence(sequence)
    {}
    void make_call(F &f)
    {
        boost::fusion::fused<F &> fused(f);
        fused(m_sequence);
    }
private:
    Sequence m_sequence;
};

// allows both immediate forwarding and delayed calls
template<typename F>
class delayed_forward_adapter
    : public boost::forward_adapter<F>
{
public:
    template<typename Sequence>
    void delay(const Sequence &sequence)
    {
        m_call.reset(new delayed_call_template<delayed_forward_adapter, Sequence>(sequence));
    }
    void make_delayed_call()
    {
        m_call->make_call(*this);
    }
    std::auto_ptr<delayed_call<delayed_forward_adapter> > m_call;
};

// something to forward to
struct print2
{
    typedef void result_type;
    
    template<typename T1, typename T2>
    void operator()(T1 &t1, T2 &t2)
    {
        std::cout << t1 << ", " << t2 << std::endl;
    }
};

struct test
{
    test(int a, int b)
    {
    };
};

template<typename T, typename Allocator=std::allocator<void> >
struct counting_factory : private boost::factory<T, Allocator>
{
    counting_factory() : count() {}

    using counting_factory::result_type;
    
    template<typename Sequence>
    typename counting_factory::result_type operator()(const Sequence &s)
    {
        count++;
        return boost::fusion::fused<boost::factory<T, Allocator> >()(s);
    }
    
    int count;
};

template<typename T, typename Allocator=std::allocator<void> >
struct perfect_factory
    : public boost::forward_adapter<
        boost::fusion::unfused_lvalue_args<
            counting_factory<T, Allocator>
        >
    >
{};

int main()
{
    delayed_forward_adapter<print2> delayer;
    
    delayer.delay(boost::fusion::vector<int, int>(3, 4));
    delayer(1, 2);
    delayer.make_delayed_call();
    
    // prints:
    // 1, 2
    // 3, 4
    
    int a=0, b=0;
    std::auto_ptr<test> p(boost::factory<test *>()(a, b));
    boost::factory<std::auto_ptr<test> >()(a, b);
    
    perfect_factory<std::auto_ptr<test> > my_factory;
    
    std::cout << "size: " << sizeof(my_factory) << std::endl;
    
    my_factory(1, 2);
    
    //std::cout << my_factory.count << std::endl;
    
    return 0;
}
