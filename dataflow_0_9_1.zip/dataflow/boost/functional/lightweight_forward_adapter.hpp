/*=============================================================================
    Copyright (c) 2007 Tobias Schwinger
  
    Use modification and distribution are subject to the Boost Software 
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
==============================================================================*/

#ifndef BOOST_FUNCTIONAL_LIGHTWEIGHT_FORWARD_ADAPTER_HPP_INCLUDED
#   ifndef BOOST_PP_IS_ITERATING

#   include <boost/config.hpp>
#   include <boost/detail/workaround.hpp>

#   include <boost/preprocessor/cat.hpp>
#   include <boost/preprocessor/iteration/iterate.hpp>
#   include <boost/preprocessor/repetition/enum.hpp>
#   include <boost/preprocessor/repetition/enum_params.hpp>
#   include <boost/preprocessor/repetition/enum_binary_params.hpp>
#   include <boost/preprocessor/facilities/intercept.hpp>

#   include <boost/call_traits.hpp>
#   include <boost/utility/result_of.hpp>
#   include <boost/ref.hpp>

#     ifndef BOOST_FUNCTIONAL_LIGHTWEIGHT_FORWARD_ADAPTER_MAX_ARITY
#       define BOOST_FUNCTIONAL_LIGHTWEIGHT_FORWARD_ADAPTER_MAX_ARITY 10
#     elif BOOST_FUNCTIONAL_FORDWARD_ADAPTER_MAX_ARITY < 3
#       undef  BOOST_FUNCTIONAL_LIGHTWEIGHT_FORWARD_ADAPTER_MAX_ARITY
#       define BOOST_FUNCTIONAL_LIGHTWEIGHT_FORWARD_ADAPTER_MAX_ARITY 3
#     endif

namespace boost 
{
    template< class Function > class forward_adapter;

    //----- ---- --- -- - -  -   -

    template< class Function > 
    class lightweight_forward_adapter
    {
        Function fnc_adaptee;

        typedef lightweight_forward_adapter<Function> self;

        template< typename T > struct qf_c          { typedef T const  type; };
        template< typename T > struct qf_c<T const> { typedef T const  type; };
        template< typename T > struct qf_c<T &>     { typedef T        type; };

        template< typename T > struct qf            { typedef T        type; };
        template< typename T > struct qf<T const>   { typedef T const  type; };
        template< typename T > struct qf<T &>       { typedef T        type; };

        typedef typename self::template qf_c<Function>::type function_c;
        typedef typename self::template qf<Function>::type function;

        typedef typename boost::call_traits<Function>::param_type func_param_t;

        template< typename T > struct gref           
        { typedef T const& type; };
        template< typename T > struct gref< boost::reference_wrapper<T> >
        { typedef T & type; };
        template< typename T > struct gref<T&>       : gref<T> { };
        template< typename T > struct gref<T const&> : gref<T> { };
        template< typename T > struct gref<T const>  : gref<T> { };

      public:

        inline explicit lightweight_forward_adapter(func_param_t f = Function())
            : fnc_adaptee(f)
        { }

        template< typename Sig >
        struct result;

        typedef typename boost::result_of<
            function_c() >::type call_const_0_result;

        inline call_const_0_result operator()() const
        {
            return this->fnc_adaptee();
        }

        typedef typename boost::result_of< function () >::type call_0_result;

        inline call_0_result operator()() 
        {
            return this->fnc_adaptee();
        }

        #define  BOOST_PP_FILENAME_1 \
            <boost/functional/lightweight_forward_adapter.hpp>
        #define  BOOST_PP_ITERATION_LIMITS                                     \
            (1,BOOST_FUNCTIONAL_LIGHTWEIGHT_FORWARD_ADAPTER_MAX_ARITY) 
        #include BOOST_PP_ITERATE()
    };
}

namespace boost 
{
    template<class F>
    struct result_of<boost::lightweight_forward_adapter<F> const ()>
    {
        typedef typename boost::forward_adapter<F>::call_const_0_result type;
    };
    template<class F>
    struct result_of<boost::lightweight_forward_adapter<F>()>
    {
        typedef typename boost::forward_adapter<F>::call_0_result type;
    };
}

#     define BOOST_FUNCTIONAL_LIGHTWEIGHT_FORWARD_ADAPTER_HPP_INCLUDED

#   else // defined(BOOST_PP_IS_ITERATING)
#     define N BOOST_PP_ITERATION() 

        template< class Self, BOOST_PP_ENUM_PARAMS(N,typename T) >
        struct result< Self const (BOOST_PP_ENUM_PARAMS(N,T)) >
            : boost::result_of<function_c(
                BOOST_PP_ENUM_BINARY_PARAMS(N,
                   typename self::template gref<T,>::type BOOST_PP_INTERCEPT)) >
        { };

        template< class Self, BOOST_PP_ENUM_PARAMS(N,typename T) >
        struct result< Self(BOOST_PP_ENUM_PARAMS(N,T)) >
            : boost::result_of<function(
                BOOST_PP_ENUM_BINARY_PARAMS(N,
                   typename self::template gref<T,>::type BOOST_PP_INTERCEPT)) >
        { };

#     define M(z,i,d) \
          static_cast<typename self::template gref<T##i>::type >(a##i)

        template< BOOST_PP_ENUM_PARAMS(N,typename T) >
        inline typename self::template result<function_c(
            BOOST_PP_ENUM_PARAMS(N,T)) >::type
        operator()(BOOST_PP_ENUM_BINARY_PARAMS(N,T,const& a)) const
        {
            return this->fnc_adaptee(BOOST_PP_ENUM(N,M,~));
        }
        template< BOOST_PP_ENUM_PARAMS(N,typename T) >
        inline typename self::template result<function(
            BOOST_PP_ENUM_PARAMS(N,T)) >::type
        operator()(BOOST_PP_ENUM_BINARY_PARAMS(N,T,const& a))
        {
            return this->fnc_adaptee(BOOST_PP_ENUM(N,M,~));
        }

#     undef M

#     undef N
#   endif // defined(BOOST_PP_IS_ITERATING)

#endif // include guard

